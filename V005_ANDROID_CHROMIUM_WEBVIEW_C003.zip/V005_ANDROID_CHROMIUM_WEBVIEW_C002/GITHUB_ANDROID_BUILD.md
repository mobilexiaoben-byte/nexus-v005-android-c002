# V005-C002 — Build APK depuis Android avec GitHub Actions

Ce dépôt est préparé pour produire l'APK C002 sans Android Studio local.

## Depuis Chrome sur Android

1. Ouvrir le dépôt GitHub contenant ce projet.
2. Ouvrir l'onglet **Actions**.
3. Choisir **NEXUS V005 C002 - Build Android APK**.
4. Appuyer sur **Run workflow**, puis confirmer **Run workflow**.
5. Ouvrir l'exécution terminée.
6. Vérifier que le job **Build DESCRIBE-ready debug APK** est vert.
7. Télécharger l'artefact **NEXUS-V005-C002-debug.apk**.
8. Installer l'APK sur l'appareil Android.
9. Ouvrir l'application NEXUS C002.
10. Si une feature WebKit obligatoire manque, STOP : résultat BLOCKED.
11. Sinon ouvrir ChatGPT dans le container, s'authentifier normalement.
12. STOP dès que l'application affiche **DESCRIBE PASS — STOP GATE**.

Ne pas lancer de requête LLM à cette gate. Le clean-device E2E appartient à V-007.

## Ce que le workflow vérifie avant build

- runner `ubuntu-24.04` ;
- JDK 17 ;
- Gradle 9.6.0 ;
- Android SDK platform 36 ;
- Android Build Tools 36.0.0 ;
- validation C002 scoped (`run_validation.sh`) ;
- compilation `:app:assembleDebug` ;
- SHA-256 de l'APK produit.
