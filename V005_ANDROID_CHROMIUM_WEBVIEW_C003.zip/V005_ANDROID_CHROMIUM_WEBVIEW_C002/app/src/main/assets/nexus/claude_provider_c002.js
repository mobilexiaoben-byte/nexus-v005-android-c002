'use strict';

(function(){
  const CHANNEL='NEXUS_POC022_C9_CLAUDE';

  const NATIVE=globalThis.NexusNativeC002;
  async function nativeSend(payload){
    if(!NATIVE || typeof NATIVE.postMessage!=='function') throw new Error('ANDROID_NATIVE_BRIDGE_UNAVAILABLE');
    NATIVE.postMessage(JSON.stringify(payload));
    return {ok:true};
  }
  function nativeOnMessage(handler){
    if(!NATIVE || typeof NATIVE.addEventListener!=='function') throw new Error('ANDROID_NATIVE_BRIDGE_UNAVAILABLE');
    NATIVE.addEventListener('message',(event)=>{
      let msg;
      try{ msg=JSON.parse(String(event.data||'')); }catch(_){ return; }
      const sendResponse=(response)=>{
        nativeSend({channel:CHANNEL,type:'PROVIDER_ACK',bridge_run_id:msg.bridge_run_id,response}).catch(()=>{});
      };
      handler(msg,null,sendResponse);
    });
  }
  let badge,running=false;

  function visible(el){
    if(!el || !el.isConnected) return false;
    const cs=getComputedStyle(el);
    if(cs.display==='none'||cs.visibility==='hidden'||Number(cs.opacity)===0) return false;
    const r=el.getBoundingClientRect();
    return r.width>0 && r.height>0;
  }

  function ensureBadge(){
    if(badge && badge.isConnected) return badge;
    badge=document.createElement('div');
    badge.id='nexus-c9-claude-badge';
    badge.style.cssText=[
      'position:fixed','right:8px','top:8px','z-index:2147483647',
      'max-width:620px','padding:8px 10px','background:#fff','color:#111',
      'border:2px solid #111','border-radius:8px',
      'font:11px/1.35 system-ui,sans-serif','box-shadow:0 3px 14px rgba(0,0,0,.18)'
    ].join(';');
    (document.body||document.documentElement).appendChild(badge);
    return badge;
  }
  function show(t){ ensureBadge().textContent='NEXUS C9 CLAUDE — '+t; }

  function findComposer(){
    const selectors=[
      'div[contenteditable="true"][role="textbox"]',
      '[contenteditable="true"][data-placeholder]',
      'div.ProseMirror[contenteditable="true"]',
      'textarea',
      '[contenteditable="true"]'
    ];
    for(const s of selectors){
      for(const el of document.querySelectorAll(s)){
        if(visible(el)) return el;
      }
    }
    return null;
  }

  function authActionTexts(){
    const accepted=new Set([
      'log in','login','sign in','sign up','signup',
      'se connecter','connexion',"s'inscrire",'s’inscrire','inscription'
    ]);
    const out=[];
    for(const el of [...document.querySelectorAll('button,a')].filter(visible)){
      const t=String(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();
      if(accepted.has(t)) out.push(t);
    }
    return [...new Set(out)].sort();
  }

  function detectAuth(){
    const composer=findComposer();
    const neg=authActionTexts();
    const positive=[];
    const support=[];

    if(composer){
      positive.push('visible_composer');
      support.push('composer_tag='+composer.tagName.toLowerCase());
      support.push('composer_role='+(composer.getAttribute('role')||''));
    }

    // Conservative C9 rule: a live Claude composer plus no visible login/signup action.
    let state='UNKNOWN',reason='NO_STABLE_CLAUDE_UI_SIGNAL';
    if(composer && neg.length===0){
      state='AUTHENTICATED';
      reason='VISIBLE_CLAUDE_COMPOSER_AND_NO_LOGIN_SIGNUP_ACTION';
    } else if(!composer && neg.length>0){
      state='UNAUTHENTICATED';
      reason='VISIBLE_LOGIN_SIGNUP_AND_NO_CLAUDE_COMPOSER';
    } else if(composer && neg.length>0){
      state='UNKNOWN';
      reason='CONFLICTING_CLAUDE_AUTH_UI_SIGNALS';
    }

    return {
      state,reason,
      observed_at:new Date().toISOString(),
      observed_at_ms:Date.now(),
      path:location.pathname,
      evidence:{
        positive,
        negative:neg.map(x=>'visible_auth_action:'+x),
        support
      }
    };
  }

  async function publishStatus(){
    const s=detectAuth();
    if(!running) show('AUTH: '+s.state+' — '+s.reason);
    try{ await nativeSend({channel:CHANNEL,type:'CLAUDE_STATUS',status:s}); }catch(_){
    }
  }

  function composerText(el){
    if(!el) return '';
    if('value' in el && typeof el.value==='string') return el.value;
    return el.innerText||el.textContent||'';
  }

  function setComposerText(el,text){
    el.focus();
    if(el.tagName==='TEXTAREA'||el.tagName==='INPUT'){
      const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      const desc=Object.getOwnPropertyDescriptor(proto,'value');
      if(desc?.set) desc.set.call(el,text); else el.value=text;
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
      return;
    }

    try{
      const sel=window.getSelection();
      const range=document.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);
      document.execCommand('insertText',false,text);
    }catch(_){
      el.textContent=text;
    }
    el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
  }

  function findSendButton(){
    const selectors=[
      'button[aria-label*="Send" i]',
      'button[aria-label*="Envoyer" i]',
      'button[data-testid*="send" i]',
      'button[type="submit"]'
    ];
    for(const s of selectors){
      for(const el of document.querySelectorAll(s)){
        if(visible(el) && !el.disabled) return el;
      }
    }
    // Last resort: small visible button near the composer containing an arrow SVG.
    const composer=findComposer();
    if(composer){
      const cr=composer.getBoundingClientRect();
      const buttons=[...document.querySelectorAll('button')].filter(el=>visible(el)&&!el.disabled);
      const nearby=buttons.filter(el=>{
        const r=el.getBoundingClientRect();
        return r.x>cr.x && r.x<cr.right+180 && r.y>cr.y-60 && r.y<cr.bottom+100 && !!el.querySelector('svg');
      });
      if(nearby.length) return nearby[nearby.length-1];
    }
    return null;
  }

  function isGenerating(){
    const selectors=[
      'button[aria-label*="Stop" i]',
      'button[aria-label*="Arrêter" i]',
      'button[data-testid*="stop" i]'
    ];
    return selectors.some(s=>[...document.querySelectorAll(s)].some(visible));
  }

  function buildPrompt(envelope){
    const pack=JSON.stringify(envelope.frozen_package,null,2);
    return [
      'You are executing a NEXUS read-only post-response audit in this authenticated Claude browser session.',
      '',
      'MANDATORY EXECUTION RULES:',
      '- Use only the supplied frozen package below.',
      '- Do NOT browse the web and do NOT perform external research.',
      '- Do NOT rewrite Analysis A.',
      '- Do NOT canonicalize anything and do NOT mutate any NEXUS state.',
      '- Return exactly ONE JSON object and nothing else.',
      '- Follow frozen_package.output_contract exactly.',
      '- For result_pack.model.provider use "Anthropic".',
      '- For result_pack.model.model use "Claude UI session — exact backend model not exposed by bridge".',
      '- Do not claim an exact internal model version.',
      '',
      'QUESTION:',
      envelope.question,
      '',
      'FROZEN PACKAGE:',
      pack,
      '',
      'Generate the completed Result Pack now.'
    ].join('\n');
  }

  function parseCandidate(text,envelope){
    const raw=String(text||'').trim();
    if(!raw) return null;
    const candidates=[raw];
    if(raw.startsWith('```')) {
      candidates.push(raw.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'').trim());
    }
    const a=raw.indexOf('{'), b=raw.lastIndexOf('}');
    if(a>=0 && b>a) candidates.push(raw.slice(a,b+1));

    for(const candidate of candidates){
      try{
        const parsed=JSON.parse(candidate);
        if(!parsed || typeof parsed!=='object' || Array.isArray(parsed)) continue;
        const required=['result_pack_version','pack_id','comparison_id','model','answer','audit'];
        if(!required.every(k=>Object.prototype.hasOwnProperty.call(parsed,k))) continue;
        if(parsed.pack_id!==envelope.context_pack_id) continue;
        if(parsed.comparison_id!==envelope.frozen_package?.comparison_id) continue;
        if(parsed.audit?.analysis_fingerprint!==envelope.frozen_fingerprint) continue;
        if(String(parsed.model?.provider||'').toUpperCase()!=='ANTHROPIC') continue;
        return {parsed,normalized_text:candidate};
      }catch(_){
      }
    }
    return null;
  }

  function findResultCandidates(envelope){
    const out=[];
    const selectors=[
      '[data-testid*="message" i]',
      '[data-testid*="assistant" i]',
      '[data-is-streaming]',
      '.prose',
      'article',
      'main div'
    ];
    const seen=new Set();

    for(const s of selectors){
      for(const el of document.querySelectorAll(s)){
        if(!visible(el)||seen.has(el)) continue;
        seen.add(el);
        const text=String(el.innerText||el.textContent||'').trim();
        if(text.length<100 || text.length>50000) continue;
        if(!text.includes(envelope.context_pack_id)) continue;
        if(!text.includes(envelope.frozen_fingerprint)) continue;
        const parsed=parseCandidate(text,envelope);
        if(parsed) out.push({el,text,parsed});
      }
    }

    out.sort((x,y)=>x.text.length-y.text.length);
    return out;
  }

  async function progress(bridgeRunId,status){
    show(status);
    try{ await nativeSend({channel:CHANNEL,type:'PROVIDER_PROGRESS',bridge_run_id:bridgeRunId,job_status:status}); }catch(_){
    }
  }

  async function waitForSendReady(composer,timeout=15000){
    const deadline=Date.now()+timeout;
    while(Date.now()<deadline){
      const btn=findSendButton();
      if(btn && composerText(composer).trim().length>20) return btn;
      await new Promise(r=>setTimeout(r,250));
    }
    throw new Error('CLAUDE_SEND_BUTTON_NOT_READY');
  }

  async function waitForStableJson(envelope,timeout=180000){
    const deadline=Date.now()+timeout;
    let validText='',validSince=0,validParsed=null,lastCandidateCount=0;

    while(Date.now()<deadline){
      const candidates=findResultCandidates(envelope);
      lastCandidateCount=candidates.length;

      if(candidates.length){
        const best=candidates[0].parsed;
        if(best.normalized_text===validText){
          if(!validSince) validSince=Date.now();
        } else {
          validText=best.normalized_text;
          validParsed=best.parsed;
          validSince=Date.now();
          show('JSON Claude complet détecté — stabilité en cours');
        }

        if(Date.now()-validSince>=8000 && !isGenerating()){
          return {
            parsed:validParsed,
            text:validText,
            json_stable_ms:Date.now()-validSince,
            candidate_count:candidates.length
          };
        }
      } else {
        validText=''; validParsed=null; validSince=0;
      }

      await new Promise(r=>setTimeout(r,500));
    }

    throw new Error('CLAUDE_RESPONSE_TIMEOUT_BEFORE_STABLE_COMPLETE_JSON__candidates='+String(lastCandidateCount));
  }

  async function executeJob(bridgeRunId,envelope){
    if(running) throw new Error('CLAUDE_PROVIDER_ALREADY_RUNNING');
    running=true;

    try{
      const auth=detectAuth();
      if(auth.state!=='AUTHENTICATED') throw new Error('CLAUDE_NOT_AUTHENTICATED:'+auth.state);
      if(envelope.provider_family!=='ANTHROPIC') throw new Error('PROVIDER_FAMILY_NOT_ANTHROPIC');
      if(envelope.external_research!==false) throw new Error('EXTERNAL_RESEARCH_FORBIDDEN');
      if(envelope.canonical_rights!=='NONE'||envelope.state_mutation_mode!=='NONE') throw new Error('STATE_MUTATION_FORBIDDEN');

      await progress(bridgeRunId,'CLAUDE_UI_PREPARING');

      const composer=findComposer();
      if(!composer) throw new Error('CLAUDE_COMPOSER_NOT_FOUND');

      const prompt=buildPrompt(envelope);
      setComposerText(composer,prompt);
      const send=await waitForSendReady(composer);

      await progress(bridgeRunId,'CLAUDE_UI_PROMPT_READY');
      send.click();
      await progress(bridgeRunId,'CLAUDE_UI_PROMPT_SENT');

      const result=await waitForStableJson(envelope);
      await progress(bridgeRunId,'CLAUDE_UI_RESPONSE_CAPTURED');

      await nativeSend({
        channel:CHANNEL,
        type:'PROVIDER_RESULT',
        bridge_run_id:bridgeRunId,
        ok:true,
        result_pack:result.parsed,
        provider_meta:{
          ui_origin:location.origin,
          auth_observation:auth,
          exact_backend_model_exposed:false,
          completion_rule:'COMPLETE_JSON_REQUIRED__STABLE_8000MS',
          json_stable_ms:result.json_stable_ms,
          candidate_count:result.candidate_count
        }
      });

      show('TERMINAL COMPLETED — résultat renvoyé à NEXUS');
    } catch(err) {
      const code=String(err?.message||err);
      try{
        await nativeSend({
          channel:CHANNEL,type:'PROVIDER_RESULT',bridge_run_id:bridgeRunId,ok:false,error:code
        });
      }catch(_){
      }
      show('TERMINAL FAILED — '+code);
    } finally {
      running=false;
      setTimeout(publishStatus,2000);
    }
  }

  nativeOnMessage((msg,sender,sendResponse)=>{
    if(!msg || msg.channel!==CHANNEL || msg.type!=='EXECUTE_JOB') return;
    if(running){
      sendResponse({ok:false,error:'CLAUDE_PROVIDER_ALREADY_RUNNING'});
      return;
    }
    sendResponse({ok:true,accepted:true});
    setTimeout(()=>executeJob(msg.bridge_run_id,msg.envelope),0);
    return;
  });

  publishStatus();
  setInterval(publishStatus,3000);
  const mo=new MutationObserver(()=>{
    clearTimeout(mo._t);
    mo._t=setTimeout(publishStatus,350);
  });
  mo.observe(document.documentElement,{subtree:true,childList:true,attributes:true});

  console.info('[NEXUS C9 CLAUDE] provider bridge active');
})();
