package nexus.android.c002.web

import android.net.Uri

object OriginPolicy {
    val bridgeOrigins: Set<String> = setOf(
        "https://chatgpt.com",
        "https://claude.ai"
    )

    fun isBridgeOriginAllowed(origin: String): Boolean = bridgeOrigins.contains(origin)

    fun isTopLevelNavigationAllowed(url: String): Boolean {
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return false
        if (!uri.scheme.equals("https", ignoreCase = true)) return false
        val host = uri.host?.lowercase() ?: return false
        return host == "chatgpt.com" || host.endsWith(".chatgpt.com") ||
            host == "openai.com" || host.endsWith(".openai.com") ||
            host == "claude.ai" || host.endsWith(".claude.ai") ||
            host == "anthropic.com" || host.endsWith(".anthropic.com")
    }
}
