package nexus.android.c002.core

import java.security.MessageDigest

enum class SelectedProvider { CHATGPT, CLAUDE, GEMINI }

data class ProviderPolicy(
    val providerFamily: String,
    val adapterId: String,
    val origin: String,
    val enabled: Boolean
)

object ProviderPolicies {
    val policies = mapOf(
        SelectedProvider.CHATGPT to ProviderPolicy("OPENAI", "ADP-OPENAI-FAMILY", "https://chatgpt.com", true),
        SelectedProvider.CLAUDE to ProviderPolicy("ANTHROPIC", "ADP-ANTHROPIC-FAMILY", "https://claude.ai", true),
        SelectedProvider.GEMINI to ProviderPolicy("GOOGLE", "ADP-GOOGLE-FAMILY", "https://gemini.google.com", false)
    )
}

data class ExecutionInput(
    val requestId: String,
    val question: String,
    val handoffText: String,
    val provider: SelectedProvider,
    val model: String? = null,
    val externalResearch: Boolean = false
)

data class FrozenPackage(
    val packId: String,
    val question: String,
    val provider: SelectedProvider,
    val model: String?,
    val handoffText: String,
    val canonicalWrite: Boolean = false,
    val stateMutationMode: String = "NONE",
    val truthWinner: String = "NONE"
) {
    fun canonicalString(): String = listOf(
        packId,
        question,
        provider.name,
        model ?: "",
        handoffText,
        canonicalWrite.toString(),
        stateMutationMode,
        truthWinner
    ).joinToString("\u001f")
}

data class ExecutionJob(
    val jobId: String,
    val contextPackId: String,
    val provider: SelectedProvider,
    val providerFamily: String,
    val adapterId: String,
    val origin: String,
    val question: String,
    val model: String?,
    val frozenPackage: FrozenPackage,
    val frozenFingerprint: String
)

data class ProviderMetadata(val providerFamily: String, val modelRef: String?)
data class ExecutionReceiptMetadata(val transport: String)

data class AndroidReceipt(
    val status: String,
    val jobId: String,
    val contextPackId: String,
    val question: String,
    val frozenFingerprint: String,
    val providerMetadata: ProviderMetadata?,
    val executionReceipt: ExecutionReceiptMetadata?,
    val canonicalWrite: Boolean = false,
    val stateMutationMode: String = "NONE",
    val truthWinner: String = "NONE",
    val answer: String? = null,
    val errorCode: String? = null,
    val forbiddenFields: Set<String> = emptySet()
)

data class ValidationResult(val pass: Boolean, val code: String)


data class BridgeDescriptor(
    val authenticated: Boolean,
    val origin: String,
    val targetCount: Int,
    val adapterReady: Boolean,
    val missingFeatures: Set<String> = emptySet()
)

object RuntimeGate {
    fun validateDescriptor(descriptor: BridgeDescriptor, expectedOrigin: String): ValidationResult {
        if (descriptor.missingFeatures.isNotEmpty()) return ValidationResult(false, "ANDROID_WEBKIT_FEATURE_MISSING")
        if (!descriptor.authenticated) return ValidationResult(false, "ANDROID_AUTH_REQUIRED")
        if (descriptor.origin != expectedOrigin) return ValidationResult(false, "ANDROID_PROVIDER_ORIGIN_MISMATCH")
        if (descriptor.targetCount != 1) return ValidationResult(false, if (descriptor.targetCount == 0) "ANDROID_PROVIDER_TARGET_MISSING" else "ANDROID_PROVIDER_TARGET_AMBIGUOUS")
        if (!descriptor.adapterReady) return ValidationResult(false, "ANDROID_PROVIDER_ADAPTER_NOT_IMPLEMENTED")
        return ValidationResult(true, "PASS")
    }

    fun validateAck(received: Boolean, correlated: Boolean): ValidationResult = when {
        !received -> ValidationResult(false, "ANDROID_ACK_TIMEOUT")
        !correlated -> ValidationResult(false, "ANDROID_ACK_CORRELATION_MISMATCH")
        else -> ValidationResult(true, "PASS")
    }

    fun validateTerminal(received: Boolean): ValidationResult =
        if (received) ValidationResult(true, "PASS") else ValidationResult(false, "ANDROID_TERMINAL_TIMEOUT")
}

class AndroidTransportEngine {
    private val completedExecutionIds = mutableSetOf<String>()

    fun buildJob(input: ExecutionInput): ExecutionJob {
        require(input.requestId.isNotBlank()) { "ANDROID_JOB_ID_REQUIRED" }
        require(input.question.isNotBlank()) { "ANDROID_QUESTION_REQUIRED" }
        require(input.handoffText.isNotBlank()) { "ANDROID_HANDOFF_REQUIRED" }
        require(!input.externalResearch) { "ANDROID_EXTERNAL_RESEARCH_FORBIDDEN" }

        val policy = ProviderPolicies.policies[input.provider]
            ?: error("ANDROID_PROVIDER_NOT_ENABLED")
        require(policy.enabled) { "ANDROID_PROVIDER_NOT_ENABLED" }

        val packId = "V005-C002-${input.requestId}"
        val frozen = FrozenPackage(packId, input.question, input.provider, input.model, input.handoffText)
        return ExecutionJob(
            jobId = input.requestId,
            contextPackId = packId,
            provider = input.provider,
            providerFamily = policy.providerFamily,
            adapterId = policy.adapterId,
            origin = policy.origin,
            question = input.question,
            model = input.model,
            frozenPackage = frozen,
            frozenFingerprint = sha256(frozen.canonicalString())
        )
    }

    fun validateReceipt(job: ExecutionJob, receipt: AndroidReceipt): ValidationResult {
        if (completedExecutionIds.contains(job.jobId)) return fail("ANDROID_DUPLICATE_EXECUTION_ID")
        if (receipt.status != "COMPLETED") return fail(receipt.errorCode ?: "ANDROID_EXECUTION_NOT_COMPLETED")
        if (receipt.jobId != job.jobId) return fail("ANDROID_EXECUTION_JOB_ID_MISMATCH")
        if (receipt.contextPackId != job.contextPackId) return fail("ANDROID_EXECUTION_PACK_ID_MISMATCH")
        if (receipt.question != job.question) return fail("ANDROID_EXECUTION_QUESTION_MISMATCH")
        if (receipt.frozenFingerprint != job.frozenFingerprint) return fail("ANDROID_EXECUTION_FINGERPRINT_MISMATCH")
        if (receipt.canonicalWrite) return fail("ANDROID_CANONICAL_WRITE_FORBIDDEN")
        if (receipt.stateMutationMode != "NONE") return fail("ANDROID_STATE_MUTATION_FORBIDDEN")
        if (receipt.truthWinner != "NONE") return fail("ANDROID_TRUTH_WINNER_FORBIDDEN")
        if (receipt.forbiddenFields.isNotEmpty()) return fail("ANDROID_SECRET_OR_ENDPOINT_FIELD_FORBIDDEN")
        val provider = receipt.providerMetadata ?: return fail("ANDROID_PROVENANCE_MISSING")
        if (provider.providerFamily != job.providerFamily) return fail("ANDROID_PROVIDER_PROVENANCE_MISMATCH")
        if (job.model != null && provider.modelRef != job.model) return fail("ANDROID_MODEL_REF_MISMATCH")
        val transport = receipt.executionReceipt ?: return fail("ANDROID_TRANSPORT_PROVENANCE_MISSING")
        if (transport.transport != "ANDROID_WEBVIEW_CHROMIUM_BRIDGE") return fail("ANDROID_TRANSPORT_PROVENANCE_MISMATCH")
        if (receipt.answer.isNullOrBlank()) return fail("ANDROID_RESULT_ANSWER_MISSING")
        completedExecutionIds.add(job.jobId)
        return ValidationResult(true, "PASS")
    }

    private fun fail(code: String) = ValidationResult(false, code)

    companion object {
        fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }
}
