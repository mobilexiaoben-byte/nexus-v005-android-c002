package nexus.android.c002

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import nexus.android.c002.core.BridgeDescriptor
import nexus.android.c002.core.RuntimeGate
import nexus.android.c002.web.NexusWebBridge
import nexus.android.c002.web.OriginPolicy
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private var bridge: NexusWebBridge? = null
    private var describePassed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.providerWebView)
        status = findViewById(R.id.status)

        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            block("ANDROID_WEBKIT_FEATURE_MISSING:MULTI_PROFILE")
            return
        }
        WebViewCompat.setProfile(webView, PROFILE_NAME)

        hardenWebView(webView)
        val chatGptAdapter = assets.open("nexus/chatgpt_provider_c002.js").bufferedReader().use { it.readText() }
        val claudeAdapter = assets.open("nexus/claude_provider_c002.js").bufferedReader().use { it.readText() }
        bridge = NexusWebBridge(webView, ::handleBridgeMessage)
        val install = bridge!!.install(chatGptAdapter, claudeAdapter)
        if (!install.pass) {
            block(install.code)
            return
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                return if (OriginPolicy.isTopLevelNavigationAllowed(url)) {
                    false
                } else {
                    block("ANDROID_NAVIGATION_ORIGIN_BLOCKED:${request.url.host}")
                    true
                }
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                describePassed = false
                bridge?.clearForNavigation()
                status.text = "DESCRIBE pending — loading $url"
            }
        }

        status.text = "C002 DESCRIBE-only runtime — open ChatGPT and authenticate; no LLM job will be dispatched"
        webView.loadUrl(CHATGPT_ORIGIN + "/")
    }

    private fun handleBridgeMessage(origin: String, payload: String) {
        if (describePassed) return
        val message = runCatching { JSONObject(payload) }.getOrElse {
            block("ANDROID_DESCRIBE_MESSAGE_MALFORMED")
            return
        }
        if (message.optString("type") != "CHATGPT_STATUS") return
        if (message.optString("channel") != CHATGPT_CHANNEL) {
            block("ANDROID_DESCRIBE_CHANNEL_MISMATCH")
            return
        }
        val auth = message.optJSONObject("status") ?: run {
            block("ANDROID_DESCRIBE_STATUS_MISSING")
            return
        }
        val authState = auth.optString("state", "UNKNOWN")
        val descriptor = BridgeDescriptor(
            authenticated = authState == "AUTHENTICATED",
            origin = origin,
            targetCount = 1,
            adapterReady = true,
            missingFeatures = emptySet()
        )
        val gate = RuntimeGate.validateDescriptor(descriptor, CHATGPT_ORIGIN)
        val out = JSONObject()
            .put("contract", "NEXUS_ANDROID_DESCRIBE_C002")
            .put("provider_family", "OPENAI")
            .put("adapter_id", "ADP-OPENAI-FAMILY")
            .put("origin", origin)
            .put("authenticated", descriptor.authenticated)
            .put("auth_state", authState)
            .put("target_count", descriptor.targetCount)
            .put("adapter_ready", descriptor.adapterReady)
            .put("model_ref", "ChatGPT UI session — exact backend model not exposed by bridge")
            .put("external_research", false)
            .put("canonical_write", false)
            .put("state_mutation_mode", "NONE")
            .put("truth_winner", "NONE")
            .put("gate", gate.code)

        if (!gate.pass) {
            if (gate.code == "ANDROID_AUTH_REQUIRED") {
                status.text = "DESCRIBE BLOCKED — ANDROID_AUTH_REQUIRED\nAuthenticate in ChatGPT; retry is automatic.\n$out"
            } else {
                block("DESCRIBE_${gate.code}")
            }
            return
        }

        describePassed = true
        status.text = "DESCRIBE PASS — STOP GATE\n${out.toString(2)}"
        // Deliberately no provider job dispatch here. V-005 runtime proof must stop after DESCRIBE.
    }

    private fun hardenWebView(view: WebView) {
        with(view.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
        }
        WebView.setWebContentsDebuggingEnabled(false)
    }

    private fun block(code: String) {
        status.text = "BLOCKED — $code"
        if (::webView.isInitialized) webView.visibility = View.GONE
    }

    companion object {
        const val PROFILE_NAME = "nexus_provider_profile_c002"
        const val CHATGPT_ORIGIN = "https://chatgpt.com"
        const val CHATGPT_CHANNEL = "NEXUS_POC022_C8B2R1"
    }
}
