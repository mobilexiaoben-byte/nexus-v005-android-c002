#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PASS=0
FAIL=0
check() {
  local id="$1"; shift
  if "$@"; then echo "PASS $id"; PASS=$((PASS+1)); else echo "FAIL $id"; FAIL=$((FAIL+1)); fi
}
check_text() { grep -Fq "$2" "$1"; }

check T01_profile_declared check_text "$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt" 'WebViewCompat.setProfile(webView, PROFILE_NAME)'
check T02_origin_restricted_isolated_bridge check_text "$ROOT/app/src/main/java/nexus/android/c002/web/NexusWebBridge.kt" 'JS_INJECTION_IN_FRAME_AND_WORLD'
check T02_no_addJavascriptInterface bash -c "! grep -R -Fq 'addJavascriptInterface' '$ROOT/app/src/main/java' '$ROOT/app/src/main/assets/nexus/chatgpt_provider_c002.js' '$ROOT/app/src/main/assets/nexus/claude_provider_c002.js'"
check T02_no_chrome_runtime_refs bash -c "! grep -Fq 'chrome.runtime' '$ROOT/app/src/main/assets/nexus/chatgpt_provider_c002.js' '$ROOT/app/src/main/assets/nexus/claude_provider_c002.js'"
check T02_adapter_sources_present test -s "$ROOT/app/src/main/assets/nexus/chatgpt_provider_c002.js"
check T02_adapter_sources_present_claude test -s "$ROOT/app/src/main/assets/nexus/claude_provider_c002.js"
check T25_no_live_surface_files bash -c "! find '$ROOT' -type f | grep -E '(Guest|MAIN).*live'"
check T03_describe_contract check_text "$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt" 'NEXUS_ANDROID_DESCRIBE_C002'
check T03_describe_stop_gate check_text "$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt" 'DESCRIBE PASS — STOP GATE'
check T03_no_execute_job_native bash -c "! grep -Fq '"EXECUTE_JOB"' '$ROOT/app/src/main/java/nexus/android/c002/MainActivity.kt'"
node --check "$ROOT/app/src/main/assets/nexus/chatgpt_provider_c002.js"
node --check "$ROOT/app/src/main/assets/nexus/claude_provider_c002.js"
"$ROOT/run_core_tests.sh"
echo "STATIC_RESULT pass=$PASS fail=$FAIL"
test "$FAIL" -eq 0
