# V005-C002-ANDROID-RUNTIME-PROOF-001

This candidate is DESCRIBE-only.

Expected runtime sequence:
1. Verify WebView features: MULTI_PROFILE, WEB_MESSAGE_LISTENER, JS_INJECTION_IN_FRAME_AND_WORLD.
2. Start isolated profile `nexus_provider_profile_c002`.
3. Load `https://chatgpt.com/`.
4. If unauthenticated, display `DESCRIBE BLOCKED — ANDROID_AUTH_REQUIRED` and allow user authentication in the WebView.
5. Provider adapter publishes `CHATGPT_STATUS` automatically.
6. Native app converts status into `NEXUS_ANDROID_DESCRIBE_C002` and validates it with RuntimeGate.
7. On success display `DESCRIBE PASS — STOP GATE` and the descriptor JSON.
8. No `EXECUTE_JOB` is emitted by the Android app in this gate.

Required PASS descriptor invariants:
- provider_family=OPENAI
- adapter_id=ADP-OPENAI-FAMILY
- origin=https://chatgpt.com
- authenticated=true
- target_count=1
- adapter_ready=true
- external_research=false
- canonical_write=false
- state_mutation_mode=NONE
- truth_winner=NONE
- gate=PASS

No DEVICE PASS exists until this has run on an Android emulator/device with a compatible System WebView.
