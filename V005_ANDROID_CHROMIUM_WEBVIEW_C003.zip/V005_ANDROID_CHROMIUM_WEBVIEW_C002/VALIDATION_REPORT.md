# V-005 C002 validation report — Chromium/WebView

## Current result
- Core transport/fail-closed: **25/25 PASS**
- Static container/DESCRIBE checks: **10/10 PASS**
- Total local executable/static checks: **35/35 PASS**
- ChatGPT provider adapter JavaScript syntax: **PASS**
- Claude provider adapter JavaScript syntax: **PASS**
- `chrome.runtime` dependency in C002 adapters: **NONE**
- Native C002 provider job dispatch during DESCRIBE gate: **NONE**

## DESCRIBE-only gate added
The Android native layer now consumes the provider's periodic `CHATGPT_STATUS` message and materializes a strict `NEXUS_ANDROID_DESCRIBE_C002` descriptor. The descriptor is validated with `RuntimeGate` and the app stops at `DESCRIBE PASS — STOP GATE` when authenticated.

The gate does not dispatch an LLM request.

## Android API compatibility checked at source level
The C002 calls map to current Jetpack WebKit 1.17.0 APIs:
- `WebViewCompat.setProfile`
- `WebViewFeature.MULTI_PROFILE`
- `WebViewFeature.WEB_MESSAGE_LISTENER`
- `WebViewFeature.JS_INJECTION_IN_FRAME_AND_WORLD`
- `WebViewCompat.getExecutionWorld`
- `WebViewCompat.addWebMessageListener(..., JavaScriptExecutionWorld, ...)`
- `WebViewCompat.addJavaScriptOnEvent`
- `JavaScriptReplyProxy.postMessage`

This is source/API verification, not an APK compilation proof.

## Build/runtime boundary
Current execution environment has JDK 21 but no Gradle, Android SDK, sdkmanager, adb, emulator, or Android device. Therefore:
- APK/DEX build: **PENDING_EXTERNAL_ANDROID_ENV**
- System WebView feature detection: **PENDING_DEVICE**
- ChatGPT auth: **PENDING_DEVICE**
- real DESCRIBE: **PENDING_DEVICE**
- provider round-trip: **NOT AUTHORIZED IN THIS GATE**
- DEVICE PASS: **NOT CLAIMED**

See `BUILD_ATTEMPT_REPORT.md`.

## Browser/cloud build readiness — 2026-09-06
- GitHub Actions workflow present: `.github/workflows/build-apk.yml`.
- Manual `workflow_dispatch` only; no automatic provider execution.
- Runner pinned to `ubuntu-24.04`.
- JDK 17 via `actions/setup-java@v5`.
- Gradle 9.6.0 via `gradle/actions/setup-gradle@v6`.
- Preflight requires Android platform 36 and Build Tools 36.0.0.
- C002 scoped validation runs before `:app:assembleDebug`.
- Direct APK artifact uses `actions/upload-artifact@v7` with `archive: false`.
- Workflow itself not yet executed against GitHub-hosted runner: CLOUD_BUILD=PENDING.
